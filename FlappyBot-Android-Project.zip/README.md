# FlappyBot (Android prototype)

This is a native Android Studio project for a screen-based Flappy Bird auto-player.

## Build
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Use
1. Install the APK on Android 11 or newer.
2. Open FlappyBot and enable **FlappyBot screen player** in Android Accessibility settings.
3. Open the Flappy Bird game, return to FlappyBot and press **Start auto-play**.
4. Switch back to the game. Press **Stop auto-play** in FlappyBot to stop.

## Important limitations and privacy
- This is an experimental prototype, not a tested universal game bot. It uses simple yellow-bird / green-pipe color detection and may fail with different themes, scaling, ads, menus, or clones.
- Android will show the Accessibility permission because the app uses it to capture screenshots and dispatch taps. Keep it disabled when not playing. Screen contents are processed locally in memory; this project contains no network code and does not upload screenshots.
- Android may prevent screenshots on protected screens. Some games may prohibit automation; use only where permitted.
- Requires Android 11 (API 30) or newer.
