package com.example.flappybot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.ScreenshotResult;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.HardwareBufferRenderer;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;

import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

public class FlappyAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicBoolean capturePending = new AtomicBoolean(false);
    private long lastTap = 0;
    private boolean busy = false;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        // Polling is used because many games render without accessibility events.
    }

    @Override public void onInterrupt() { }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        handler.post(loop);
    }

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (getSharedPreferences("bot", MODE_PRIVATE).getBoolean("running", false)
                    && Build.VERSION.SDK_INT >= 30 && capturePending.compareAndSet(false, true)) {
                takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                    @Override public void onSuccess(ScreenshotResult result) {
                        try {
                            Bitmap bitmap = Bitmap.wrapHardwareBuffer(result.getHardwareBuffer(), result.getColorSpace());
                            if (bitmap != null) {
                                Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
                                result.getHardwareBuffer().close();
                                if (copy != null) {
                                    analyzeAndMaybeTap(copy);
                                    copy.recycle();
                                }
                            } else {
                                result.getHardwareBuffer().close();
                            }
                        } catch (Exception ignored) { }
                        capturePending.set(false);
                    }
                    @Override public void onFailure(int errorCode) { capturePending.set(false); }
                });
            }
            handler.postDelayed(this, 180);
        }
    };

    private void analyzeAndMaybeTap(Bitmap b) {
        int w = b.getWidth(), h = b.getHeight();
        if (w < 100 || h < 100) return;

        // Ignore status/navigation margins and scan for a yellow bird.
        int left = w / 12, right = w * 11 / 12;
        int top = h / 10, bottom = h * 9 / 10;
        long sx = 0, sy = 0, count = 0;
        int step = Math.max(1, Math.min(w, h) / 300);

        for (int y = top; y < bottom; y += step) {
            for (int x = left; x < right; x += step) {
                int c = b.getPixel(x, y);
                int r = Color.red(c), g = Color.green(c), bl = Color.blue(c);
                if (r > 190 && g > 135 && g < 235 && bl < 105 && r > g * 1.05) {
                    sx += x; sy += y; count++;
                }
            }
        }
        if (count < 5) return;
        int birdX = (int)(sx / count), birdY = (int)(sy / count);

        // Look for a pipe gap in a vertical slice ahead of the bird.
        int probeX = Math.min(w - 2, birdX + w / 5);
        int gapTop = -1, gapBottom = -1, bestTop = -1, bestBottom = -1;
        boolean inGap = false;
        for (int y = top; y < bottom; y += step) {
            int c = b.getPixel(probeX, y);
            int r = Color.red(c), g = Color.green(c), bl = Color.blue(c);
            boolean greenPipe = g > 75 && g > r * 1.22 && g > bl * 1.12;
            if (!greenPipe && !inGap) { gapTop = y; inGap = true; }
            if (greenPipe && inGap) {
                gapBottom = y;
                if (bestTop < 0 || gapBottom - gapTop > bestBottom - bestTop) {
                    bestTop = gapTop; bestBottom = gapBottom;
                }
                inGap = false;
            }
        }
        if (bestTop < 0 || bestBottom < 0 || bestBottom - bestTop < h / 12) return;

        int targetY = (bestTop + bestBottom) / 2;
        long now = System.currentTimeMillis();
        // Gentle feedback control; throttle taps to avoid flooding the game.
        if (birdY > targetY + h / 35 && now - lastTap > 150) {
            Path path = new Path();
            path.moveTo(w / 2f, h / 2f);
            GestureDescription gesture = new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(path, 0, 35))
                    .build();
            dispatchGesture(gesture, null, null);
            lastTap = now;
        }
    }
}
