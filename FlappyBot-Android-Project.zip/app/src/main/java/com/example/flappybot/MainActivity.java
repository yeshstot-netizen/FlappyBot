package com.example.flappybot;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);

        TextView title = new TextView(this);
        title.setText("FlappyBot");
        title.setTextSize(28);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("A prototype that detects a yellow bird and green pipes in the current screen, then taps using Android Accessibility.\n\n1. Enable “FlappyBot screen player” in Accessibility settings.\n2. Open your Flappy Bird game.\n3. Return here and tap Start.\n4. Switch back to the game. Tap Stop here or disable the service to stop.");
        info.setTextSize(16);
        layout.addView(info);

        Button settings = new Button(this);
        settings.setText("Open Accessibility Settings");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(settings);

        Button start = new Button(this);
        start.setText("Start auto-play");
        start.setOnClickListener(v -> {
            getSharedPreferences("bot", MODE_PRIVATE).edit().putBoolean("running", true).apply();
            info.setText("Auto-play requested. Switch to Flappy Bird. This prototype works best with a simple yellow-bird / green-pipe version.");
        });
        layout.addView(start);

        Button stop = new Button(this);
        stop.setText("Stop auto-play");
        stop.setOnClickListener(v -> {
            getSharedPreferences("bot", MODE_PRIVATE).edit().putBoolean("running", false).apply();
            info.setText("Auto-play stopped.");
        });
        layout.addView(stop);
        setContentView(layout);
    }
}
